# Video Editing Memory

Generic lessons from AI-assisted editing of talking-head + b-roll videos (Enlgish or Hindi narration, 4K, YouTube).
Read this before starting a new video.
Channel-specific choices live in each channel's `STYLE.md`, not here.
The `ve.py` driver and the toolkit layout are described in the repo's `CLAUDE.md`.

## Folder layout (creator's rule, 2026-10-15)

- `CLAUDE_VE_ALL/` (repo root) keeps only what every edit needs: code (`ve.py`, `vekit/`), tools, venv, design kit, reusable templates, SFX, FCP DTD.
- `<CHANNEL_FOLDER><MAIN_FOLDER>/CLAUDE_VE/` keeps everything for that one video (project.json, timeline.py, transcripts, audio, its graphics, FCP project + mezzanine, builds, previews, plans, facts).
- Never create helper folders anywhere else; per-video graphics link the shared kit with `shared -> ../../../../CLAUDE_VE_ALL/gfx/_shared`.
- Keep the layout in one module (`vekit/paths.py`) and store repo-relative paths in timelines; the 2026-10-15 move then needed only that module, a re-plan and a re-export of the FCP file.
- After moving folders, recreate the venv (activate scripts and entry points keep the old absolute path) and regenerate FCPXML files (they hold absolute media URLs).
- Verify a restructure by comparing per-frame hashes (`-f framemd5`) of the rendered shots and the mix hash before and after.

## Pipeline that worked

- Use ffmpeg for all footage work (cuts, punch-ins, b-roll, audio, final encode) and a browser-based renderer (HyperFrames: HTML + GSAP) only for graphics.
- Rendering a 10+ minute 4K timeline entirely in a browser renderer is slow and fragile; render graphics as short clips instead.
- Render graphics as ProRes 4444 MOV with alpha: transparent for overlays, opaque for full-screen cards.
- Author graphics at 1920x1080 and render 4K with `--resolution landscape-4k` (2x device scale), so one layout serves both resolutions.
- Build one template per graphic type driven by variables, plus a JSON spec of items; new text then needs no HTML edits.
- Render the edit as one intermediate file per shot (ProRes via `prores_videotoolbox`), in parallel, then join with the concat demuxer (`-c copy`).
- On Apple Silicon, `prores_videotoolbox` encodes 4K at roughly 100+ fps and `-hwaccel videotoolbox` decodes 10-bit HEVC A-roll fast.
- Run shot renders with about as many parallel jobs as performance cores (10 on an M3 Max kept the CPU near 1400%).
- Key each shot's cache by a hash of its ffmpeg command, so edits re-render only the shots that changed.
- Keep the whole edit as data (a timeline file of kept segments, visuals anchored to raw timestamps, overlays), and generate everything from it.
- Anchor b-roll and overlays to raw source timestamps of spoken words, not to output times; anchors then survive changes to cut points.
- Review with a Final Cut Pro project, not a rendered preview; render nothing (preview or 4K) until the creator explicitly asks (creator's rule, 2026-10-16).
- Final delivery that worked: 3840x2160, frame rate matched to the A-roll, H.264 High around 40 Mbps, AAC 320 kbps, `+faststart`.
- ffmpeg's native `aac` encoder undershoots the requested bitrate (320k gave about 237 kbps); on macOS use `aac_at -aac_at_mode cbr -b:a 320k`.
- `h264_videotoolbox` treats `-b:v` as a ceiling (about 15 Mbps instead of 40); add `-constant_bit_rate 1` when using the hardware encoder.
- Always ffprobe the delivered file's video and audio bitrates instead of trusting the encoder flags.
- A two-pass libx264 encode at 4K is slow (tens of minutes); the hardware encoder is minutes and visually very close at 40 Mbps.
- `h264_videotoolbox` treats `-b:v` as a ceiling and undershoots badly on easy footage (15 Mbps instead of 40 on a talking-head Short); add `-constant_bit_rate 1`. The native `aac` encoder also undershoots 320k on speech; `-c:a aac_at -aac_at_mode cbr -b:a 320k` hits it. Always ffprobe the delivered bitrates.

## Transcription (Hindi / Hinglish)

- NEVER run many Whisper processes at once: 8 parallel `transcribe.py` runs (~3.6 GB RSS each plus GPU buffers) froze the creator's machine (2026-10-23). `vekit/whisper_gate.py` now allows at most 2 machine-wide (flock slots in `CLAUDE_VE_ALL/.whisper/`) and waits for 12 GB available memory; every script that loads Whisper must call `acquire()` first.
- `mlx-whisper` with `whisper-large-v3` runs well on Apple Silicon; install it in a local venv.
- One-time model download takes a few minutes; budget for it.
- Whisper falls into repetition loops ("अब अब अब...", "प्रश्न पर प्रश्न पर...") over long pauses and retake gaps in raw footage.
- Fix: detect silences (ffmpeg `silencedetect`, about -38 dB, 0.35 s), transcribe each speech chunk separately with `condition_on_previous_text=False`.
- Use `temperature=0.0` only; the default temperature fallback produced garbled English on Hinglish chunks.
- Pass a Hindi `initial_prompt` that contains the English tech words you expect; it fixes script and spelling a lot.
- On very short clips (a few seconds) the initial prompt can leak into the output as hallucinated text; don't trust short-window results blindly.
- Keep both the full first pass and the chunked pass; each recovers words the other misses.
- Latin brand and tech terms are often misheard in Hindi mode (for example "Qi2" became "चीटू", "MagSafe" became "maxif"); never copy them from the transcript to the screen.
- A script or transcript from the creator speeds this up a lot: correct spellings, intended chapter titles, and a faster alignment pass instead of a full transcription.

## Finding takes and cut points

- Raw A-roll usually contains several takes of each line; keep the last complete take unless it is clearly worse.
- Hindi retake cues to search for: "वापस लेते हैं", "रिपीट", "रिटेक", "पूरा पार्ट वापस".
- Directions to the editor spoken on camera ("यहाँ screen डालना", "next screen", "page number 7") mark where the creator wants chapter cards; use them, then cut them out.
- When listing kept segments by hand it is easy to record the last word's START time as the segment end; that clips the final word.
- Always extend a segment end to the end of its last word.
- Whisper word end times are often early, especially before a pause.
- Robust snapping: extend the out point until the audio stays about 10 dB above the room-tone floor or below for 80 ms; do the same backwards for the in point; never cross into a neighbouring word.
- Snap cut points to video frame boundaries and cut audio at the matching sample (48 kHz at 23.976 fps is exactly 2002 samples per frame), so sync stays exact.
- Put 8 ms fades on every audio cut to avoid clicks.
- Watch for verbal slips inside a good take (a missing "नहीं" that flips the meaning) and trim the clause when the sentence still reads naturally.
- Verify the edit end to end: re-transcribe the edited voice track and read it for clipped words and leftover retake fragments.

## Pacing rules that worked for long videos

- Average shot length around 2.5-3 s.
- At the start of each new sentence show the host for 1.5-3 s, then cut to b-roll or a graphic.
- Hide jump cuts on the host by alternating wide framing and a punch-in of about 115-120%, centred on the face.
- Automatically flag shots shorter than about 0.9 s (accidental flashes) and longer than about 5.5 s (needs a cutaway); deliberate holds such as data cards are fine.
- Absorb slivers under about 10 frames into the previous shot.
- 30 fps phone b-roll in a 23.976 timeline: slow it to 80% (`setpts=1.25*PTS`) so every frame is used and motion stays smooth, instead of dropping frames.
- Give locked-off b-roll a slow push-in (about 100% to 106%) so it never looks frozen.
- When a b-roll slot is longer than the clip, move the in-point earlier before resorting to freezing the last frame.
- Clips of phone UI animations (for example a charging ring) often show the animation only briefly; sample frames to find the exact window before choosing an in-point, especially for split screens.

## B-roll handling

- File names are only partly descriptive (camera names like `C9768.MP4` say nothing); make a contact sheet of 4 frames per clip and look at every clip before planning.
- Write a short catalogue (id, product, what happens, frame rate, duration) and plan from that.
- Check frame rate and colour transfer of every clip with ffprobe; mixed 23.976/30 fps and 8/10-bit sources are normal.
- For text cards over b-roll, shift the b-roll to the right half on a dark background with a feathered left edge (alpha mask), so text sits on the clear side.
- Name shot types in the timeline (host, b-roll, shifted b-roll, full graphic, split screen) so the renderer stays generic.

## Hindi (Devanagari) text and fonts

- Render Devanagari through a real text-shaping engine (a browser); Pillow without libraqm cannot shape conjuncts and matras correctly.
- Mukta (Google Fonts, OFL) worked very well: Devanagari and Latin designed to match, weights 200-800, clean at all sizes.
- Noto Sans Devanagari is a solid alternative; system fonts like Kohinoor or Devanagari Sangam are less suited to bold video titles.
- Ship font files locally with `@font-face`; never rely on network fonts at render time.
- Check rendered frames for nukta letters (क़ फ़ ज़), conjuncts (र्ड, क़्क़, ज्ञ, र्भ) and matras; zoom in on a 4K crop.
- Give Devanagari headlines a line-height of at least about 1.12 and some padding so top matras and descenders are not clipped.
- Keep tech terms, units and brand names in Latin script (Qi2, MagSafe, mAh, W, USB-C); viewers read and search them that way.
- Avoid glyphs the font may lack (emoji, circled digits); the middle dot "·" is fine in Mukta.
- Don't let titles break at a hyphen; for "A: B" titles, break after the colon.
- Keep pop-ups to 2-5 words and auto-shrink long ones (for example 72 to 60 px, then two balanced lines).
- Place overlays in the lower third, away from a centred host's face; full-width layouts belong on full-screen cards.

## HyperFrames gotchas

- Never put a CSS `transform` on a property that GSAP animates; use `fromTo` (lint error `gsap_css_transform_conflict`).
- Center with flex or inset, not `translate(-50%)`, on animated nodes.
- `snapshot` overwrites the snapshots folder each run; copy frames you want to keep.
- Lint rejects `../` asset paths; a symlink inside the project works.
- Renders are cancelled if the parent process exits; run them from a live shell or a background job with stdin detached.
- Root `data-duration` is fixed at compile time; give each template type a fixed duration.
- Re-rendering the same composition is not always bit-identical (GPU rasterisation of gradients); skip graphics that are already up to date instead of re-rendering them.
- When a graphic must stay on screen longer than its animation, freeze a frame just BEFORE the exit animation and play the exit at the end; freezing the last frame holds a faded-out card.

## Audio

- Lavalier A-roll is often the same signal on both channels; downmix to mono, process, then duplicate to stereo.
- A mono signal duplicated to stereo measures about 3 LU louder; measure loudness on the final stereo file.
- ffmpeg `loudnorm` silently switches to dynamic mode when the true-peak target cannot be met with a linear gain, which flattens the voice.
- Better: high-pass about 80 Hz, light `afftdn`, gentle compression, then a static gain measured on the stereo programme to reach -14 LUFS, then a limiter (about -1.5 dBFS).
- Keep SFX subtle: whoosh into chapter cards, soft pop on pop-ups, click on a subscribe button; mixed roughly 16-22 dB below their -3 dBFS peak.
- SFX can be synthesised with numpy/scipy (filtered noise sweeps, pitch-dropping sines) with a fixed random seed; no downloads needed.

## Facts and claims

- Check every number shown on screen against the official product page and recent launch coverage.
- When the host's claim disagrees with the official spec, flag it to the creator with sources and let them decide; never silently change or add facts.
- Show prices only when the host says them, with "लगभग" (approx.) when the host says "around".
- Mark illustrative charts clearly (for example "सांकेतिक") so they are not read as measured data.

## QA checklist before showing a preview

- Every overlay and full-screen graphic: extract a frame at its hold point from the composited preview and review contact sheets.
- Look for faded holds, overlays over blurry b-roll moments, text over faces, clipped Devanagari, unbalanced layouts.
- Re-transcribe the edited audio to catch clipped or doubled words.
- Measure final loudness (`ebur128`) and check duration, frame rate, resolution and bitrate with ffprobe.

## Working with the creator

- Ask the standing questions once (language of speech and on-screen text, music, captions style, SFX, ending, review checkpoints, encoder) and reuse the answers.
- Review flow: written edit plan, then the Final Cut Pro project; the 4K render only when the creator asks for it.
- Keep a timing log per step and exclude time spent waiting for the creator.
- Things the creator can do to speed up the next edit:
  - record each section as its own clip and keep only the good take
  - name files by section
  - share the script with the screen titles
  - pause briefly before each retake
- Parallel helper agents work well for independent pieces (graphic templates, custom animations, SFX) once the shared spec and style are written down.
- Reuse templates, the build script and the SFX set across videos; most of the first video's time went into building them.

## Shorts (9:16) - learned on 6951SahiJawab

- Phone-shot vertical A-roll is stored as 3840x2160 with a -90 rotation tag; ffmpeg autorotates on decode, so treat it as 2160x3840.
- Build graphics at 1080x1920 and render with `--resolution portrait-4k` for the final; a 720 preview can use the native 1080x1920 renders scaled down.
- In a seated desk framing the empty backdrop above the host's head (top ~23%) is the best text zone: tags and hits at y 90-330, captions at y 340-470 (1080x1920 layout). Hands and products occupy the middle, and the Shorts UI covers the bottom ~22% anyway.
- Full captions work best as one HyperFrames overlay track for the whole video, generated from phrases anchored to raw times; 2.5 min renders in ~1.5 min at 1080x1920 and ~5 min at 4K (identical frames are reused).
- When the host holds products most of the time, real "b-roll" can come from the A-roll itself: crop ~2x onto the product with the crop top below the chin so mismatched lips never show, plus a slow push-in. For a close-up of the same moment, use a synced crop instead, so any visible lips stay in sync.
- A close-up of the live host (~1.3x) must keep the face below the caption zone; compute the crop top from the face position rather than zooming around the centre.
- Cutaway animations should have no exit and keep moving to the last frame; size each slot to at most the animation length so the build never freezes a frame.
- Cut out every pause longer than ~0.3 s for Shorts; merge neighbouring segments when snapping leaves a gap under ~0.12 s, otherwise audio is doubled or a pointless jump cut appears.
- Never extend a host shot across a jump cut to absorb a sliver: the removed pause then plays under the next words (lip-sync error).

## Word timings

- Whisper prints words as start|word|end; when reading short-window results, the first word's start is often just the window start. Cross-check against the chunked pass before using it as a cut point.
- Decide per timeline whether segment ends are word ENDS or word STARTS and record it (`SEG_END_IS_WORD_START` in timeline.py); the snapping logic needs to know.
- Whisper hallucinates loops ("कर दो कर दो", "यहां पर यहां पर") on short or quiet windows; re-check a suspicious junction with a different window before trusting it.
- Whisper output stops after ~30 s of audio per call; transcribe long edited blocks in windows under 30 s when checking the cut.

## Fonts (more)

- Baloo 2 (Google Fonts, OFL) is a punchy Devanagari display face for Shorts; its line box is ~1.6 em tall, so size text boxes from measured glyph bounds (canvas `measureText` actualBoundingBox*), or matras and the reph poke out of solid blocks.

## Shared tools and parallel sessions

- When several Claude sessions work in the same repo, a change to a shared build script by one session can silently change another video's cut.
- Before a final render, re-plan and compare the plan with the approved preview's plan (segments, total length); stop if anything differs.
- Keep per-video behaviour behind per-project settings (project.json or timeline flags), never by changing shared defaults.

## Shell gotcha

- zsh does not word-split unquoted `$var` in loops (`for r in "a b"; cmd $r` passes one argument); use arrays, functions, or Python for multi-argument loops.

## A-roll media in Final Cut Pro (creator's rule, 2026-10-29)

- NEVER make a ProRes mezzanine, remux or copy of the A-roll for FCP; link the original file where it is. Older notes below that describe upright mezzanines, timecode-free remuxes and hard links are superseded.
- Why the copies existed and how the original is handled now: the rotation flag (FCP, like AVFoundation, applies the track transform, so a vertical camera file shows upright) and the camera timecode (`plan.py` stores the timecode FCP sees as `tc_start` and `fcpxml.py` offsets every A-roll in-point by it). Only a QuickTime `tmcd` track counts: Sony XAVC MP4 keeps its timecode in an `rtmd` metadata stream (ffprobe shows it as a stream tag) that FCP ignores; offsetting by it made FCP reject all 42 A-roll clips with "Invalid edit with no respective media".
- The ProRes LT copy of 9 minutes of vertical 4K was 21.7 GB; the creator objected to the disk space and the time.
- Reframing a landscape A-roll for a vertical Short (the 7064 approach) must be done with FCP transforms on the original, not with a cropped mezzanine.

## Final Cut Pro review round trip - learned on 6951SahiJawab (v2, built from scratch)

- FCP 12.3 reads and writes FCPXML 1.14; its DTDs ship inside the app (`Interchange.framework/.../Resources/FCPXMLv1_14.dtd`).
- xmllint cannot open the DTD at the app path (spaces); copy it out and validate every generated file with `xmllint --dtdvalid`.
- `adjust-transform` position is in percent of the frame height, +y up; scale multiplies the media after it is fitted to the frame.
- Connected clips are anchored to a spine clip, and their `offset` is in that clip's own timeline (which starts at its `start`), not in sequence time.
- Audio fades are `<adjust-volume><param name="amount"><fadeIn|fadeOut duration=.../></param></adjust-volume>`; FCP clip volume tops out at +12 dB.
- Give FCP an upright ProRes mezzanine of rotated phone A-roll (same frame count, no timecode) so rotation never depends on FCP; ProRes LT at 2160x3840 is about 16 GB for 6:45.
- Keep one timeline model in frames; write FCPXML from it, read FCP's export back into it, and render only from it, so preview and final share one code path.
- Self-check every export by reading it back and diffing against the model; it caught media flags that differed only by default values.
- Put the measured voice gain on the A-roll clips so FCP playback is at the final loudness; the renderer still applies one final static gain.

## HyperFrames as a graphics engine for an ffmpeg edit

- `render` only supports 24/30/60 fps; render at 24 and re-time 1:1 to 23.976 with a lossless two-step remux (`-video_track_timescale 24000`, then `-bsf:v setts=pts=N*1001:dts=N*1001:duration=1001`); a one-step setts from the 1/12288 track timescale rounds the frame times.
- `--format mov` gives ProRes 4444 with alpha (yuva444p12le); a 4 s 1080x1920 graphic renders in about 2 s, and about 6 s with `--resolution portrait-4k`.
- A single-scene graphic needs no timed clips: a plain wrapper avoids the `nested_structure_needs_subcomposition` warning.
- Copy each project into a temp dir with an absolute `shared` symlink before rendering, so parallel renders never collide on `.hyperframes/`.
- Building 30+ graphics with 4 parallel agents worked well with one written spec (GFX_SPEC.md: contract + list with the spoken line per graphic), a shared design kit, and one reference graphic built first.
- Write "key message readable by 0.9 s" into the spec; Shorts slots are often 1-2 s, and a hook title that lands at 1.0 s is barely seen.
- A camera push-in (1.06) grows edge text past the safe zone by the last frame; author text inside a slightly smaller box.

## Cutting and QA (more)

- In a very quiet room the energy floor + 10 dB can be about -65 dB; where two words touch, cut at the energy valley between them and never past the neighbouring word from the transcript.
- Re-transcribe the edited mix in ~15-20 s windows; it found a "...dation" tail before a word and a missing word at two joins.
- To choose a tricky in-point, transcribe from several candidate starts (with 0.3 s of silence prepended) and keep the range where the text is clean.
- Hindi-mode Whisper mangles English sentences in a Hinglish edit; check English lines with `language="en"`.
- Words that are coarticulated ("है-आप") have no clean cut point; drop the phrase or keep both words.
- Anchors that land a few frames from a jump cut create slivers; snap anchors within ~8 frames onto the cut.
- Cache rendered shots by the command plus the size and mtime of every input file; a re-rendered graphic at the same path otherwise leaves stale shots.
- This ffmpeg build has no `drawtext`; label contact sheets with Pillow instead.
- `ffprobe -count_frames` on a 17 GB ProRes file decodes everything (minutes); compare frame counts from metadata or a short decode instead.

## Lessons from 6951SahiJawab v3 (2026-10-15, from scratch in 28 min to review)

- Fast path that worked: extract audio and start both Whisper passes in the background first, start the ProRes mezzanine and a web fact-check agent in parallel, and plan while they run.
- Get each graphic's exact slot length by planning with placeholder compositions (`data-duration` 12), then write the spec with slot + ~0.6 s as `data-duration`.
- Add a reusable drawn-product helper to the kit (`SJ.bank`) and build one reference graphic yourself before fanning out; four agents then produce a consistent set of 31 graphics in ~10 minutes.
- Spec rule to state explicitly: no numbers on screen that the host does not say (an agent added an illustrative 0-100% battery count-up).
- Baloo 2 slabs fail HyperFrames `text_box_overflow` at line-height 1.15; agents used line-height 1.66-2 with bottom padding per graphic.
- `SJ.fit` must measure an inline-block text span, not a padded slab, or long text runs into the slab edges (fixed in the hit template).
- `SJ.bg` dots can drift above the frame on graphics of 4.5 s or more (`container_overflow`); change the seed.
- Set `voice_gain_db` to the measured static gain and pick SFX levels after that; SFX levels are absolute, so a +11 dB final gain otherwise lifts whooshes to near voice peaks.
- A quiet filler phrase coarticulated with a trimmed clause ("आता है-यहीं पर है देखिए") cannot be cut cleanly; drop it too and join at the next clean word.
- Check every in-point against the word's own start, not the window start: "प्राइसेज" lost its onset when the segment began 0.14 s late.
- A part recorded at the end with an on-camera note to the editor ("यह वाला editor जगह तो डाल देना") belongs next to its related section; record the choice in the edit plan.

## Lessons from 6121MoiPhone (2026-10-15, long 16:9 video, two A-roll parts, real b-roll)

- The toolkit now takes several A-roll parts (`("a2", t, ...)` in timeline.py), landscape projects, real b-roll (`B:<id>`), transparent overlays (`OVL`) and per-project pop-up / end templates; re-plan an older project after kit changes and diff its timeline.json to prove nothing moved (Sahi Jawab planned identically).
- Camera A-roll with a timecode track (Sony XAVC) only needs a stream-copy remux without timecode for FCP (`-c copy -map_metadata -1 -write_tmcd 0`, seconds for 12 GB); never transcode 30 min of 4K to ProRes just for that.
- Give every b-roll use its own conformed ProRes clip (exact 23.976, every source frame once, 1 s handles, push-in baked with `zoompan`); FCP and the renderer then share identical frames, and 59 clips render in about 80 s with VideoToolbox.
- Put each b-roll's usable window (`lo`/`hi`) in the timeline; the planner moves the in-point earlier or warns when a slot outgrows the window.
- Long raw footage (30 min) had 4-5 takes per line; chunk-pass gaps longer than a few seconds were silence (Whisper filled them with "कर दो" loops), not missed speech; confirm with RMS before trusting that.
- 30 min of raw Hindi A-roll: both Whisper passes in about 13 min when the two parts run in parallel (4 processes).
- A fact-check agent plus two b-roll catalogue agents in the first minutes paid off: box prints ("QCPD 3.0 Protocols") settled a claim the official page did not list, and the catalogue flagged a lock screen with a personal name and desk clips showing other channels' YouTube thumbnails.
- HyperFrames `remove-background` is a person/salient-object model: it fails on products lying on a table (kept flowers, lost the product) and drops products held in hand from a person cut-out.
  Cut rounded-rectangle products geometrically from an overhead still; place product cut-outs into the host's empty hands for thumbnails.
- Adding a channel kit inside `gfx/_shared` used to change every other channel's graphic cache key; channel kits now live in `_shared/<kit>/` and enter the key only when referenced.
- 7 graphics agents built 54 landscape graphics in about 20 minutes from one spec table (slot, duration, spoken line, visual); agents synced cues to real word times by themselves when given `words.py`.
- Agents sharing the scratchpad overwrote each other's helper scripts; tell each agent to use `scratchpad/<group>/`.
- `MP.words()` (and `SJ.words()`) rebuild the text, so coloured spans inside a split headline are lost; colour the word spans after splitting.
- GSAP shifts an SVG element when the transform origin is given only in the end values of a scaled `fromTo`; put the same `svgOrigin` in both.

## Lessons from 6973 (House of Tech Short, 2026-10-15, 7 laptops, from scratch to review in 43 min)

- Folder names with spaces and `&` work end to end: `Path.as_uri()` percent-encodes them in FCPXML and ElementTree escapes the event name; always quote the path in shell loops.
- Check the design kit against `hyperframes check` contrast before fanning out: white on #ff6b1a failed 3:1, and four agents each patched it locally with slightly different oranges. Fix shared colours once in the kit.
- `document.fonts.ready` can resolve before a weight that is only used by JS-built text has loaded; call `document.fonts.load("900 100px Poppins")` (each weight) before measuring or fitting text.
- A sheen drawn with `linear-gradient(100deg, ...)` on a tall, narrow box shows a hard vertical edge; use 90deg.
- Keep rotations of travelling elements within 20 degrees, or mark deliberate swings with `data-layout-allow-orbit`, or `check` warns `rotation_pivot_drift`.
- Poppins (OFL) shapes Devanagari well (conjuncts, nukta) and gives a punchy tech look; give Devanagari lines line-height 1.25+.
- The chunk pass can compress a line ("16GB RAM, 1TB Storage" was really "16GB की RAM ... 1TB का storage आपको मिल जाता है"); a cut at the chunk word end clipped "storage". When a chunk line looks telegraphic, re-transcribe that raw window alone before choosing the out-point; the QA re-transcription of the mix caught it.
- A pause inside a chunk can hide a false start ("Asus में build quality, जो इसकी build quality"); find the restart onset from the 10 ms energy envelope and pin it with `{"in": "exact"}`.
- Spec claims depend on the exact listing: the creator's Acer link had no MS Office while sibling listings do; fact-check against the linked listing, not the model family.
- Planning with 12 s placeholder compositions, then a cue table (record-time offset of every word inside each graphic slot, from the segment map) let 6 agents sync reveals to the voice without running the planner themselves.
- Thumbnails: author 1920x1080 HTML, export with HyperFrames, scale to 1280x720; host cut-outs from `remove-background` need a cleanup pass (plant fragments on the shoulders, coloured hair fringe from the backdrop).

## Lessons from 4719ApnaTrader (Apna Trader, 2026-10-15, long 16:9, 25 fps camera + synced iPad screen recording)

- The frame rate is a timeline property now (`project.json` "fps", default 24000/1001); 25 fps camera A-roll needs no conversion, and 48 kHz audio is 1920 samples per frame.
- HyperFrames 0.8.157 renders any rate (`--fps 25`, `24000/1001`); the "24/30/60 only" limit is gone, so non-23.976 projects render graphics natively without re-timing.
- Prove a shared-toolkit change is backward compatible by planning the other videos with the old and the new code in memory and comparing the JSON; FCPXML output was byte-identical too.
- A screen recording made during the take is a second camera angle: sync it by cross-correlating 10 ms RMS envelopes of the two audio tracks (the offset was constant over 23 min), and let each b-roll slot follow the A-roll's jump cuts (`"sync"` b-roll).
- iOS screen recordings are variable frame rate (nb_frames / r_frame_rate gives a wrong length); pick frames by timestamp (`fps` filter after `-ss`) and take the length from the container duration.
- An iPhone-only app recorded on an iPad sits in the middle of the frame with black bars; measure the app bounds from column / row means and crop to it.
- Two alternating layouts kept a 20-minute demo lively: a phone-shaped device beside a chapter label (static background rendered once by HyperFrames) and a zoomed band chosen from where the screen changes (frame-difference energy per horizontal band).
- 4K ProRes for 10 minutes of screen-recording b-roll fills the disk; hardware HEVC at 50 Mbps is plenty for UI footage and FCP plays it.
- For a 20-minute edit, generate the shot list from rules (sentence starts from the chunk pass, cover zones, graphic ranges) in record time instead of placing 300 shots by hand; keep the rules in a per-video script and the zones in a readable shot plan.
- A cold open that reuses a line makes raw anchors ambiguous (they map to the first use); anchor the later visuals in raw time that only the second take contains.
- Long explainer graphics can be broken by host shots at sentence starts and resumed with `G:<name>@<sec>`; the graphic's clock keeps running, so agents sync to one continuous cue table.
- Back-to-back graphics with tiny host gaps between them create flash frames; let the earlier shot run on when the gap is under ~0.6 s.
- Product links in the brief can be stale (laptop links on an option-trading tutorial); use them only when the video is about those products, and say so in the plan.
- The Claude Code safety check blocks `cd dir; rm -f dir/*` style globs; delete generated files by explicit absolute paths.

## Lessons from 4719ApnaTrader v2 (2026-10-16, redone from scratch, host + synced iPad screen)

- Tablet/phone screen recordings with a host: `broll.py` synced layouts take a `pip` key (A-roll file, sync offset, face crop, box) that bakes a lip-synced host circle into the same mezzanine as the screen; ring, bezel and chapter label live in a HyperFrames-rendered background plate (one per layout and chapter). 94 such 4K HEVC clips rendered in about 4 minutes.
- Both Whisper passes can silently drop 10+ s of continuous speech (1093-1107 s here) or garble a passage the other pass gets right; before treating a transcript gap as a retake or silence, check the 100 ms RMS and the other pass.
- Split the chunk pass at a mid-file silence and run the halves as two processes next to the full pass: 23 minutes of Hindi audio transcribed in 7 minutes.
- When a host speaks without pauses, "break long graphics at sentence starts or jump cuts" finds nothing; fall back to the word start nearest the target interval, otherwise 15-20 s graphics survive.
- Chapter cards should have a fixed length from their anchor (2.8 s), not a word-to-word span; word anchors made some cards 6 s long.
- Decoding a 23-minute 60 fps iPad HEVC recording for a frame-difference map took about 6 minutes even at `fps=4`; start it in the background early (it is cached).
- Long labels in narrow layout columns: allow two lines at full size instead of letting `AT.fit` shrink them to 40 px.
- Thumbnails + meta.txt make a good parallel agent task right after transcription; the fact-check agent finished in about 3 minutes.
- Re-transcribing the edited mix found three repeats that both raw passes had compressed into one word ("बनेगा" spanning 3.5 s hid a full retake); a long word duration in either pass is a sign of hidden speech.
- When a cut lands inside a graphic that agents already synced, don't edit the animation: resume the graphic at its authored clock right after the cut (`G:<name>@<authored sec>`, a JUMPS table in the shot generator).
- Host pieces of a few frames between jump cuts flash wide/tight; `project.json` "min_framing_frames" (12) gives them the neighbouring piece's framing. Wordless pieces (breaths, clicks) between removed pauses are better trimmed from SEGS.
- A website opened in Safari during an iPhone-app screen recording is full width; detect such windows (brightness outside the app column) and give them their own crop.

## Lessons from 6991 Apna Trader (2026-10-16, 16:9 news explainer, SEBI screenshots, from scratch to review in 27 min)

- A video folder can sit inside a channel folder (`Apna Trader/6991 ...`): MAIN is then `<CHANNEL>/<VIDEO>`, the graphics' kit link needs one more level (`../../../../../CLAUDE_VE_ALL/gfx/_shared`), and `ve.py fcp` now names the FCPXML after the video folder only (it used to put the slash into the file name).
- A 6.5-minute single take needs no chunk splitting: both Whisper passes finished in 3 minutes; plan from the chunk pass and the full pass together.
- Screenshots of websites and circulars work best as HyperFrames graphics, not zoompan b-roll: the image on a "sheet", a camera that moves between targets, gold marker boxes that draw in on the words the host reads, and a one-line Hindi caption bar.
  Let one agent own the screenshot rig (or put it in the kit) before others start; two agents built two slightly different rigs and had to be aligned afterwards.
- Rig details that mattered: `clipPath` cuts off `box-shadow`, so wipe with pixel insets that include the glow (or keep the glow on its own layer); a caption bar over a white page needs `backdrop-filter: blur(14px)`; a caption that fades in fails the contrast check mid-fade, so slide it in.
- The fact-check agent found the effective date the creator asked for inside the circular itself (para 6.1); ask it for dates and circular numbers, not only for the host's claims.
- `sheet.py` time labels cover the top-left corner of every frame; crop the unlabelled frame before chasing "clipped" titles there.
- The 4K render took 14.5 minutes for a 4-minute video, most of it rendering the 57 graphics at 4K; once the creator asks for the render, start `ve.py gfx <MAIN> --res 2160` in the background (with the locks) first, so the rest is only shots and encode.
- The creator may skip the Final Cut Pro round trip and ask for the 4K straight from the reviewed timeline; re-plan and `cmp` the timeline.json against the preview's copy before rendering.

## Lessons from 6991 Apna Trader v2 (2026-10-16, redone from scratch, review files in 35 min)

- The shared venv lives in `CLAUDE_VE_ALL/.venv` (hidden from plain `ls`); check with `ls -a` before recreating it.
- The review FCPXML now goes to `<MAIN>/output/` (creator's rule); `ve.py fcp` writes it there and its media stay in CLAUDE_VE.
- The screenshot rig is in the Apna Trader kit: `shared/at/shot.js` (`ATShot.build`) puts the page in a rounded viewer panel over `AT.bg`, moves a camera between targets in image pixels, draws highlighter/box/underline marks on cue, and swaps caption lines; build one reference graphic with it, then two agents did 11 screenshots in ~9 minutes.
- Caption lines parked outside the caption bar fail the contrast check over a white page even when clipped; hide inactive lines with `visibility`.
- A short word left before a join can vanish ("आप 3:31 से | आप order" re-transcribed as "331 order"); prefer cutting to the fluent second take of the whole phrase, at the quiet gap after the filler word.
- Fact flags can hide in scope words: the host said the CAS close applies to "सारे shares" in cash, but it applies only to F&O stocks; trimmed the clause (creator's rule) and kept the matching graphic for a restore.
- The fact-check agent finished in 2 minutes when given the circular number and screenshot paragraphs; ask it for the old framework too (old timings made the thumbnail and description stronger).
- With slots planned first (placeholders + cue table), 4 programmatic agents (7-8 graphics each) and 2 screenshot agents finished in 9-24 minutes; render each group at 1080 as it lands so `ve.py fcp` only renders the last group.
- HyperFrames `check` prints a StaticGuard font notice for kit fonts declared in `at.css`; use the kit classes rather than declaring `font-family` in a graphic's own style, or the compiler injects Google Fonts copies.
- zsh: `"$i:layout"` applies the `:l` (lowercase) modifier; write `${i}:layout` in ffmpeg filter strings.

## Lessons from 6991 Apna Trader v3 (2026-10-17, from scratch, review files in 45 min)

- Both Whisper passes on a 6.6-minute take finished in under 3 minutes; the slowest step was the graphics fan-out (6 agents, 36 graphics, about 30 minutes), so start it as early as possible.
- Tell each graphics agent to clean up only inside its own folders: one agent ran `rm -rf */.hyperframes/artifacts/snapshots` from `gfx_src/` and deleted the other groups' snapshots mid-review.
- Agents label old rules with the circular's date ("Jan 2026 CAS") although the rule went live later (Aug 3, 2026); put the live date of every old/new rule into the spec next to the circular date.
- Labels split across `<br />` or `<span>` defeat a plain `sed`; grep the result after every text fix in a graphic.
- A spec cue table needs hand-corrected words wherever the chunk pass hallucinated (re-transcribe those windows alone); agents sync reveals to whatever the table says.
- Render each agent group at 1080 as it lands and review a 4-frame strip per graphic in one image; it caught label and fact problems before the FCP export.

## Lessons from 4718 Apna Trader (2026-10-19, 26-minute take + synced iPad demo, from scratch to review in ~60 min)

- The shared Hugging Face cache can lose model weights to another process (a shared blob store cleanup removed both Whisper models); Whisper then hangs at "Fetching 4 files" with 0% CPU.
  `snapshot_download` hung on the Xet path too; `curl -L` of `resolve/main/weights.npz` (8 byte ranges in parallel) into the model's own `blobs/<sha256>` slot, checked with `shasum -a 256` against the blob name, fixed it.
  Run transcription with `HF_HUB_OFFLINE=1` so it never waits on the hub.
- Camera A-roll without a timecode track (Nikon MOV) needs no remux for FCP: a hard link as `fcp/media/<name>_A-roll.mov` costs no disk and no time.
- Synced iPad demo layouts are now a per-video script (`4718 .../CLAUDE_VE/scripts/plates.py`): it computes the screen and circle rectangles exactly as `broll.synced_cmd` does, renders one HyperFrames plate per layout and chapter label, and returns the BROLL specs; copy it for the next app-demo video.
- Pick the zoom band per screen piece from the frame-difference map (mean energy of the band's rows); ticking watchlist prices give ~0.1, real taps and scrolls >0.3.
- Long graphics can be broken automatically inside timeline.py: any graphic piece over 7.5 s gets a 1.8 s host shot at the word start nearest its middle (sentence starts preferred), resumed with `G:<name>@<offset>`; offsets come from the previous plan's segment map, so plan twice.
  This took a 20-minute edit from 50 graphic shots of 8-19 s to a 7.4 s maximum without hand placement.
- Agents use count-up animations by default, which flash numbers nobody says (₹68,000 on the way to ₹1.5 लाख, "−₹0.41", "115 Qty"); write "spoken amounts pop to their value, no count-ups" into the spec.
- The QA re-transcription found five problems the raw passes hid:
  - Whisper word times were early ("theta" really ended 0.33 s later), so the snapped out-point clipped it; pin the out-point at the energy valley before the next word.
  - An in-point left the tail of a dropped word ("इसे मान लीजिए" was heard as "इससे मान").
  - Two false starts sat inside kept ranges ("Nifty एक पैसे इसी तरह से", "अगर आप trade, अगर आप trade").
  - A one-second chunk-pass word ("रुपए") hid a whole restart ("हमने सत्तर हमने सत्तर").
  Transcribing a short window from 3-4 candidate in-points (0.3 s silence prepended) settles the exact cut in seconds.
- `ve.py plan` "short host shot" warnings of 4 frames are often breaths between two removed pauses; check the transcript words there and cut wordless ones out of SEGS.
- Thumbnails in Canva (creator's request): upload frames with `create-upload-url` + one raw POST, cut the host out with Canva remove-background, `create-design` "YouTube Thumbnail", fix texts with edit-design, export PNG.
  Canva picked a thin condensed font that garbled "शुरू" and joined "5 में से" into one word; read every export at full size.
  YouTube tags are limited to 500 characters in total.

## Lessons from 4718 v2 (2026-10-19, creator's review: tablet whenever he looks at it, no zoom, highlights)

- Apple Vision gives head pitch per frame (`VNDetectFaceRectanglesRequest` revision 3, Swift, ~135 fps on 960x540 JPEGs): looking at the camera is about -7 to +4 deg, looking down at a tablet on the desk +15 to +25 deg; pitch >= 12 deg for at least 1 s found 312 s of "looking at the tablet" in a 20-minute cut.
- Wrap every iteration of a long Swift Vision loop in `autoreleasepool`; without it Vision silently returned no faces after ~4,400 frames (all results empty, no error).
- Apple Vision OCR (`VNRecognizeTextRequest`, accurate, en-US) reads a broker app's UI almost perfectly (strike chips, "Lot size: 65", "Required", "Swipe to buy", tabs); 1,600 frames in under a minute as 4 parallel processes.
- Highlights "on what the host is talking about": map spoken terms to app elements with a short rule list, look the element up in the OCR of the frame that is on screen at that moment (never an earlier frame: the UI may already have changed), and make each highlight its own transparent overlay clip (gold box + slight dim of the rest of the app) so the creator can edit them in FCP.
  Rules need context: "market 75-76 पर चल रहा" is the price, not the Market button; "open से closed में आ गया" should mark Closed.
- When the tablet takes priority over graphics, keep the title and chapter cards whole (subtract them from the tablet spans) and drop graphic pieces shorter than 2 s.

## Lessons from tmp/weightloss (2026-10-20, English, AI presenter + TTS voice-over, from scratch to review in ~25 min)

- Script-generator inputs: per paragraph a short vertical host clip (first sentence, lip-synced) plus a voice-only WAV for the rest; the folder's own `project.json` held the script and per-beat graphic ideas, worth reading first.
- Model each paragraph as one A-roll part: host clip, then the WAV on a plain plate (always covered by graphics); the toolkit then needs no audio-only concept.
- The renderer and `crop_filter` assume the A-roll is the project size; put vertical host footage into a 16:9 mezzanine at project size (4:5 upper-body card on the channel background) and force `HW` framing so no punch-in scales the layout.
- TTS voices have no room tone: the planner's snapping left only 0.07-0.15 s at host/voice-over joins; pin joins `exact` from the 5 ms envelope (speech bounds at -45 dB) for ~0.30 s within a paragraph and ~0.36 s between paragraphs.
- `transcribe.py` and `vekit.qa_transcribe` take `--lang en`; English TTS transcribes almost perfectly in 2 minutes, but a word can be missing ("Bonus:") - check gaps in the energy envelope.
- Generate the cue table from the planned timeline; slots whose first word fell into the previous slot ("55" at the end of the trial slot) were fixed by moving the VIS anchor to the phrase's first word, then re-planning.
- A trimmed clause can be cut cleanly in TTS at the energy valley between words ("That's | three eggs, | a cup"), pinned `exact`.
- One reference graphic plus a written spec let 7 agents build 32 graphics (incl. 4 transparent title overlays) in 7-10 minutes; render each group at 1080 as it lands and review 4-frame strips (overlays composited over the host mezzanine).
- A `$` drawn as SVG text inside overlapping icons fails the contrast check; draw glyph-like marks as paths. A highlighter bar with `z-index: -1` warns `negative_z_index`; put the text in its own positioned span instead.

## Lessons from 7048 Moi Phone (2026-10-23, 9:16 Short, 59.94 fps phone A-roll + overhead b-roll, from scratch to review in 28 min)

- 59.94 fps timelines work now: `Rate.spf` is fractional (800.8 samples per frame) and `Rate.samples(frames)` rounds frame boundaries down to whole samples; 23.976/25 stay exact integers, and re-planning older projects gave identical timeline.json.
- B-roll much slower than the timeline (23.976 in 59.94) must play in real time (`fps` filter, 3:2 repeats); "every source frame once" would fast-forward it 2.5x. `broll.py` switches automatically above a 1.3 rate ratio.
- Overhead phone b-roll can be recorded upside down; BROLL keys `"rotate": 180` and `"crop": [x0, y0, x1, y1]` (9:16 window of the rotated 16:9 frame, aspect checked) make vertical b-roll without a separate conform step.
- Run a privacy pass on screen b-roll before planning: the creator's clip showed his name on the card and in Settings, the CVV, and a notes app with bank logins and passwords. Give the catalogue agent the job of listing unusable ranges, and pass them to the thumbnail agent too (it had been pointed at a frame with the card holder's name).
- Demo b-roll may not show the promised result (the card add failed, "Card Not Added"); check the end state of every demo before writing "done" ticks into overlays, and flag it to the creator.
- Both Whisper passes looped badly on a retake-heavy 3.5-minute take; transcribing every energy run separately (34 windows, 0.3 s silence prepended) gave clean text in 2 minutes.
- The QA re-transcription found a breath heard as "कि" before the first word (pin the in-point at the energy valley) and an unscripted filler between two words of a kept sentence (two exact pins around it).
- Keep each graphics agent's spec cue table up to date after trimming; a removed filler moved the cues of one graphic by 0.4 s, sent to the agent mid-build.
- QA without a preview: run `render.shot_cmd` for one frame at the start and middle of every shot (`-frames:v 1` to JPEG) and tile them; it shows exactly what the render will composite, in about 20 s.
- Another session may be editing the same channel in parallel: check `find -newer` on CLAUDE_VE_ALL before touching shared files, message it (ListAgents/SendMessage) about shared changes, and keep per-video helpers (here `v.css`/`v.js`) inside the video folder.

## Lessons from 7064 Moi Phone Short (2026-10-23, Apple Pay how-to, 4 landscape A-roll parts, from scratch to review in ~42 min)

- Landscape 4K camera A-roll for a 9:16 Short: build one vertical mezzanine per part (full-height 1216x2160 crop centred on the median Vision face x, lanczos to 2160x3840, ProRes LT, same frame count, PCM audio) and point project.json "aroll" at it; FCP and the renderer then need no portrait logic. Four parts (10 min) took about 2 minutes with VideoToolbox.
- Mixed A-roll rates (59.94 host, 23.976 demo): pick the host rate; the slower part is conformed in its mezzanine with `fps=60000/1001:round=near` (frame repeats), so the timeline stays one rate.
- Overhead phone demos are often filmed upside down: rotate 180 in the mezzanine and in every overhead b-roll (`"rotate": 180` plus a 9:16 `"crop"` around the phone).
- Highlight boxes on a filmed phone screen: OCR the mezzanine frames (Vision, 2 fps over the kept ranges), then define every mark in RAW time of the part (screen-change times measured from frame differences), never in record time; record-time marks drifted 0.3-0.5 s after later cut-point fixes and pointed at screens that were already gone.
- A raw anchor on a part's LAST kept frame maps to the end of the edit (planner rule "next kept frame"); a host shot vanished and an overlay ran 70 s long. Anchor 0.03 s inside the next segment instead, and end overlays on the last piece of a part one frame early.
- Composite every overlay over the frame under it (spine frame at 15 % and 80 % of the overlay) before export: it caught boxes outliving their screen, a "+" box on the wrong icon, and two app screens showing the cardholder's full name and city that no frame sample had shown.
- Personal data in screen demos: Wallet / bank-app setup screens show the account name ("Name ...", the name printed on the card art, location) for a second or two; cover them with colour-matched patches inside the overlay (under the dim layer), timed to the exact screen-change frames.
- Cut points where words touch: print the 5-10 ms envelope around every cut whose edge is above about -40 dB, pin the valley `exact`, and confirm by transcribing 3-4 candidate in/out points (0.3 s silence prepended). Found here: a "वैसे" tail, a "क्यों" onset, a hidden false start ("अब यह अच्छी" inside a 1.1 s word), and an out-point that kept "लेकिन".
- The end hold needs real silence: when the closing line runs into the next sentence, end the line `exact` and append a 0.05 s piece of room tone from after the last "thank you"; END_HOLD extends that piece, covered by the last graphic and the dark fade.
- A rotating "+" badge reads as "x" at 45 degrees ("iOS 18 x" = not supported); never rotate plus signs, pulse them.
- Graphics agents hit `MP9.fit` shrinking a block title to minPx when maxW is smaller than the block's width, and `MP9.rich` spans losing their leading space directly inside a flex box; both are in the moi9 README now.

## Lessons from 7096 Moi Phone Short (2026-10-28, review in 24 min)

- When passes disagree on a number (69,499 vs 69,999), transcribe the number alone from 2-3 staggered starts in Hindi AND English mode (`windows.py --lang en`); English mode reads numbers reliably.
- Whisper loops on retake-heavy chunks hide real speech; `CLAUDE_VE_ALL/windows.py` (0.3 s silence prepended, pieces under 4.5 s, one model load) recovered all eight looped ranges in 2 minutes.
- A cue table must map words through record time (`raw2rec`), not by raw offset from the slot start: a slot that begins in the tail of the previous segment otherwise lists words of dropped takes.
- Price cards from one reference: `scripts/cards.py` rewrites only a CFG line and `data-duration`; `white-space: nowrap` on the fitted title is essential (`MP9.fit` measures scrollWidth, so a wrapped long name never shrinks and falls into the art); a badge over the art must come after it in the DOM.
- Partial renders while agents work: filter `gfx.jobs_for()` by name and call `gfx.render_one` directly; a name filter like `price_*` also catches `price_up_17`, so the placeholder renders once and is replaced by the cache key.
- Audio QA without a picture build: `render.render_audio(tl, pdir, 720)` makes the mix, `vekit.qa_transcribe` reads it; set `voice_gain_db` to the clip gain plus the measured static gain so FCP plays at the final loudness.
- QA frames of opaque ProRes 4444 graphics: extract directly; an `overlay` over a `color` source gave only the background colour.
- zsh does not split `"$a $b"` in `for w in ...; set -- $w`; use a Python loop for multi-argument queries.

## Lessons from 7064 Moi Phone LONG (2026-10-23, same Apple Pay footage as the Short, 16:9 at 59.94)

- NEVER start many Whisper processes at once: 8 parallel `transcribe.py` runs froze the creator's machine; `vekit/whisper_gate.py` now caps it at 2 machine-wide and waits for 12 GB free. Four parts still transcribed in 6 minutes.
- Camera A-roll parts with a timecode track: stream-copy remux for FCP (seconds); a slower, upside-down part (23.976 overhead demo in a 59.94 edit) gets its own upright 59.94 mezzanine (hflip,vflip + `fps=60000/1001:round=near`, hardware HEVC 60 Mbps, PCM) and project.json "aroll" points at it (`CLAUDE_VE/mezz/a3_upright.mov`).
- 16:9 Moi Phone graphics can use the portrait kit's drawn art: link `shared/moi9/mp9.css` THEN `shared/moi/mp.css` (landscape page sizing wins), scripts mp.js + mp9.js, `MP.bg` for the background and `MP9.phone/card/icon/waves` for the art. `.mp-title` has line-height 1.16; set >= 1.22 per graphic for Devanagari.
- A Whisper chunk word of 0.8 s ("अब") hid a whole phrase ("setup procedure के लिए"); the QA re-transcription of the mix found it, and the 50 ms energy envelope showed the in-point was still clean.
- Graphics agents correctly refused unsaid claims ("और भी जल्द" when the host never says "soon"); check pop-up texts against the same rule.
- Privacy on screen demos must be verified on the COMPOSITED render, not trusted from the overlay author: OCR (Apple Vision) of every 2nd composited frame of every demo shot, searching for the names/places found earlier, found 6 leaks after the agent's frame-tracked patches (home-screen app label renamed with the first name, Wi-Fi name in a Settings open animation, the printed card name while the card is in the hands).
- Overlays anchored 0.03 s inside a piece end 2 frames early when the piece borders a graphic (not a jump cut, where the planner snaps them onto the cut); privacy patches there need the overlay to run to the piece edge.
- ffmpeg `select` inside a filter_complex passed (almost) all frames and scrambled the image numbering of a "every 2nd frame" dump; frame-exact checks must write every frame in order and pick files by index instead.

## Lessons from 7096 v2 (2026-10-28, redo after a folder reset, review in ~70 min)

- A folder reset (no CLAUDE_VE left) does not lose the lessons: the previous session's MEMORY.md section told the numbers (69,499 dispute, silence at 254-281) before any transcription ran; verify them again anyway.
- Parallel agents can die mid-run on an API usage limit; have the critical path finishable by the lead: graphics groups were built+rendered per group with `gfx.render_one` name filters, the lead re-checked (one `content_overlap` in a word-staggered title; explicit `#w1/##w2` spans fixed it) and rendered the last group itself.
- `windows.py` asserts 16 kHz mono; to re-check a range of the edited mix, downmix `build/<res>/mix.wav` with `-ac 1 -ar 16000` first. QA transcription windows that start mid-number can drop lakh numbers silently; re-transcribe the straddled ranges directly before believing words are missing.
- Thumbnails without a preview: 1920x1080 HyperFrames compositions rendered as 2 s mov, last frame grabbed with `-sseof -0.2` (INPUT option - before -i, ffmpeg rejects it after), scaled to 1280x720; `thumb_src/<n>/` sits beside gfx_src so its `shared` link is also five levels.
- Devanagari word-stagger titles: `MP9.words()` on a two-word title tripped `content_overlap` persistently; write the word spans in the HTML (one with `m9-hl`) and tween those.
- The plan merge rule reads frame gaps (`<= 3` frames), so SPLIT_PAUSES cuts inside a take still split (0.8 s pause = 19 frames); a host VIS anchor on the second piece lands exactly on the cut.

## Lessons from 6981 House of Apps English (2026-10-29, English Short, vertical Sony camera A-roll, from scratch to review in 37 min)

- A Sony camera can record vertical: the file is 3840x2160 with a -90 display matrix and plays upright after autorotate; check `stream_side_data` rotation before planning any reframing.
- A fan in the room kept pauses at -40..-50 dB while speech was -13..-30 dB, so the planner's floor+10 dB threshold (-51 dB) found no pauses; project.json `energy_threshold_db` (-38 here) fixes snapping and pause splitting for noisy rooms.
- Chunk-pass first words started up to 1.3 s before the real onset (the word is stretched back to the chunk start); take in-points from the energy envelope, not the word time.
- A -38 dB out-point clipped soft endings ("smartphone" lost "phone", "terms" lost its "s"); transcribe every out-point at the chosen point and 0.35 s later (and every in-point 0.35 s earlier) - it found both in one minute.
- English mode for Whisper was right for an English host with Hindi crew chatter between takes; detect the language on a few windows first (the auto-detect on the first 30 s said Hindi because of the chatter).
- A fact agent found a price ~20 % below every listing (#3 "41,000" vs 48,990); the clause was trimmed and its graphic kept for a restore. Brand feature names differ from what the host says ("AI power, deep clean" = IFB "DeepClean powered by AI"); give the official names to the graphics agents mid-build.
- A fact agent put the user's email address into a User-Agent header of a web request; tell research agents explicitly never to send personal data in headers or queries.
- Compare every on-screen text with the spoken line: official product and feature names are fine, an unsaid claim is not ("Control from your smartphone" where the host said "access").
- A headline that scaled from 2x ran past both edges during its entrance; entrances should grow from below 1x.
- The Canva thumbnail agent replaced Canva's generated backgrounds (artefacts, seams) with Pillow-rendered ones uploaded to Canva.

## Lessons from 6981 House of Apps Robot Vacuum Short (2026-10-29, English, from scheduled start to review in 32 min)

- A sibling session on the same channel (Dishwasher Short, same day) had already made the channel style, the `hoa` kit and a finished reference graphic; copying its GFX_SPEC.md contract and adapting its reference graphic (one `sed`) saved the whole design pass. Read the sibling's CLAUDE_VE first when a channel is new to you.
- English A-roll in a very quiet room (floor about -70 dB): cut at -55 dB from the 10 ms envelope; slow word decays ("machine", "five hundred", "station") run 0.3-0.8 s past Whisper's word end, so put the out-point where the decay falls below about -45 dB, not at the first frame under the threshold.
- A line spoken ~10 dB softer, laughing, and heard the same broken way from three staggered starts ("After seven weeks of dust collection...") is better dropped than patched; record it in the plan with the raw range so the creator can restore it.
- The robot on the desk and in the creator's b-roll may not be any of the reviewed products: compare it with the official photos (a look showed no match) and keep such b-roll out of the product sections.
- On a seated vertical frame the punch-in anchor comes from a look at the contact sheet, not from a computed face box. Same set as the sibling video, same anchor.
- Check on-screen texts by hand: text scraped from HTML/JS (SVG namespaces, path data, JS fragments) and slot-only word fragments are not usable input; hand-read on-screen texts plus the full spoken sentence gave a usable list (the remaining flags were allowed product-name chips, the known price gap, and one real unsaid app feature "Schedule").
- QA composites over the mezzanine near its end need `setpts=PTS-STARTPTS` on both inputs, or the overlay silently disappears (`CLAUDE_VE/scripts/qa_frames.py`).
- One frame from the middle of every shot through `render.shot_cmd` (frames 1, JPEG output) at 720 is a full-edit visual QA in seconds without a build (67 shots).
- `gfx.render_one` caches on the composition sources; a product PNG replaced in `gfx_assets` after a render needs a forced re-render of the graphics that use it.

## Lessons from Kudrat Care 001 (2026-11-09, Hindi Short, Nikon filmed sideways, review in 22 min)

- A camera can store vertical footage sideways with NO rotation flag (Nikon 3840x2160, head at the right). project.json `"aroll_rotate": {"a1": 270}` (clockwise degrees) now handles it: the renderer transposes, the FCPXML links the original with its own native-size format, `adjust-conform type="none"` and `rotation="90"`; round trip and DTD pass. B-roll uses `"rotate": 270` per BROLL entry. Premiere export does not support it yet.
- A per-video `scripts/rgfx.py <names> --check --force` (check + render at 1080 + 4-frame strip) let 4 graphics agents finish 19 cards in 6-11 minutes.

## Lessons from Kudrat Care 003 (2026-11-10, Hindi Short, sideways Nikon, review in ~21 min)

- For a sideways A-roll make a tiny upright proxy first (`transpose=2,scale=432:768`, h264_videotoolbox, seconds) and look at its contact sheet. This host's eyeline sits slightly off-lens all the time; only the "down" spans (reading notes) are real cover candidates.
- Sideways Nikon b-roll: `"rotate": 270` per BROLL entry plus `"scale"`/`"pos"` (FCP transform, pos in % of frame height, +y up) to punch in on the action; a 1.4x punch-in also cropped a competitor's bottle label at the frame edge.
- This ffmpeg has no vid.stab; `deshake=rx=64:ry=64:edge=mirror` on the needed range only, written as ProRes via prores_videotoolbox (7.5 s of 4K in 31 s), then pointed BROLL at the stabilized file inside CLAUDE_VE/broll/stab/.
- A very hot A-roll (-6.5 LUFS raw) gets `voice_gain_db` -7.5 so FCP plays at -14 LUFS; re-run `ve.py audio` after setting it (static gain should be ~0).
- `ve.py frames` needs the pop-up graphics too; run `ve.py gfx <MAIN> --res 1080` first or it fails on hit_01.mov.
- Per-video `scripts/cues.py` (slot length + word offsets per graphic from build/timeline.json and the chunk pass) plus 4 graphics agents built 25 compositions in 10-14 minutes; a product-card agent can start with a drawn stand-in and swap in the cut-out when the product agent delivers.
- `rgfx.py` prints "OK" even with layout warnings that do not contain "warn"; agents should read the full `hyperframes check` output.

## Lessons from Kudrat Care 002 (2026-11-10, Hindi Short, Nikon sideways again, review in ~30 min)

- Head on the RIGHT of a sideways raw frame = rotate 90 counter-clockwise: ffmpeg `transpose=2` (= `"rotate": 270` in project.json/BROLL). `transpose=1` gives upside-down frames; look at one still before briefing agents (the thumbnail agent got the wrong direction first and needed a correction).
- For a sideways A-roll look at the contact sheet of a small upright proxy (540x960 h264_videotoolbox, inspection only); slight head turns are not "away".
- Product links can point to a different product than the host names (link "VLCC" = a Lotus kit): the product agent should report brand mismatches first; keep the spoken brand on screen with a drawn box, flag it in info.txt and meta.txt.
- File names of b-roll describe the clip, not the moment: "mixing ..." showed a still table for its first 23 s; sample every 2 s with timestamps before choosing in-points, and check the b-roll ingredient matches the step (masoor-dal pink paste must not cover the rice-flour step).
- Re-transcribed QA windows split on quiet points can cut a soft final consonant ("निखा"); check the 20 ms envelope at the cut before believing a word is clipped.

## Lessons from Kudrat Care 005 (2026-11-11, Hindi Short, sideways Nikon, review in ~25 min)

- The creator can correct product links mid-edit: start the product agent early, but have the card and thumbnail agents wait for a rewritten products.md (with the old links marked superseded) instead of trusting the first cut-outs; a SendMessage to the three affected agents redirected everything with no lost time.
- `voice_gain_db` is applied at plan time (clip volume); after changing it, re-run `ve.py plan` before `ve.py audio`, or the mix still reports the full static gain.
- A copied per-video `cues.py` can carry the previous video's word filter (003 hid 87-96 s); check copied scripts for video-specific constants.
- Give the six ingredient labels to one agent (one family from 003's `lbl_neem`); it finished in 3 minutes and they match exactly.
- Clipped-looking text at the very top of `ve.py frames` sheets can be the time labels; crop the raw graphic render before chasing it.

## Lessons from Kudrat Care 004 (2026-11-11, Hindi Short, sideways Nikon, review in ~19.5 min active)

- The creator can correct product links mid-edit; have the product agent move the old set to `assets/products_old_links/` (never delete) and tell graphics/thumbnail agents to ignore it.
- Map each link to the brand the host names and compare her claims with the listing early: "whiten" (listing says pigmentation/darkness) and "men's and women's" (link is For Women) were both trimmed as fact flags; send the new slot lengths to the graphics agents right away.
- Whisper fills long silent holds (host waiting before showing a product) with loops; a 100 ms RMS print of the whole file separates silence (-91 dB) from speech in seconds on a short take.
- `ve.py frames` needs `end_fade` rendered first: `scripts/rgfx.py end_fade --render --render-only`.

## Lessons from Kudrat Care 006 (2026-11-11, Hindi Short, sideways Nikon, review in ~20 min)

- A pasted brief can arrive truncated (header with MAIN_FOLDER / VIDEO_TYPE / PRODUCT_LINKS missing); with the creator unavailable, the only video folder of the channel with no CLAUDE_VE/output (others had live sessions) was the target, and the channel defaults filled the rest. Say so at the top of info.txt.
- Hosts may say "ये" about products they never hold up; check frames before planning host shots over product lines (product agent reports held-up ranges).
- `windows.py` on gaps between takes loops ("प्रति प्रति ..."): those gaps were silence, not speech.
- A per-video `scripts/cues.py` copied from a sibling had that video's dropped-range filter hardcoded; strip it when copying.

## Lessons from Kudrat Care 014 (2026-11-13, Hindi Short, sideways Nikon, review in ~22 min)

- A sibling video with nearly the same recipe (012) made the whole pass fast: copy its project.json settings (rotate, templates, SFX levels, punch-in anchor for the same set), its scripts (rgfx.py, cues.py) and its GFX_SPEC.md structure; write the new spec with cue offsets right after one placeholder plan.
- The chunk pass looped over one 4-second line ("बालों के लिए" x40) while the full pass had it cleanly; take that slot's cue offsets from the full pass by hand.
- Hosts name a pack type the listing contradicts ("pouch" vs a plastic jar): keep the audio, use the listing's product name on screen, flag it in info.txt.
- rgfx.py does not write 4-frame strips; every agent wrote its own. Add strip output to the per-video rgfx.py next time.

## Lessons from Kudrat Care 015 (2026-11-13, Hindi Short, sideways Nikon, review in ~20 min)

- Whisper writes long silences and look-away pauses as loops ("पास पास", "प्रश्न प्रश्न", "आपको आपको"); one `windows.py` call over all looped ranges plus the retake zones (11 windows, one model load, ~1 min) settled every take before planning.
- A brief that says "if the site blocks, use a browser User-Agent" gets an agent refused by the auto-mode classifier (bot-check circumvention); ask product agents to use the normal fetch/search tools and the brand's own site as the fallback.
- The product agent writes `assets/products.md`, not `assets/products/products.md`; give card agents the exact path, or they finish without reading the fact flags.
- Starting graphics agents right after the plan (placeholders + cue table), with the pop-ups, end fade, b-roll conform, audio gain and QA transcription done by the lead in the meantime, made the FCP export about 1 minute after the last agent finished.
- Thumbnail agents copy spoken ranges loosely ("15 मिनट" when she said "15-20 मिनट"); check numbers on thumbnails and titles against the transcript.

## Lessons from Kudrat Care 013 (2026-11-13, Hindi Short, sideways Nikon, review in ~27 min active)

- The creator corrected the product links again mid-edit (third Kudrat video in a row); resuming the finished product agent with SendMessage (move old set to `products_old_links/`, reuse cut-outs only for identical product+variant) took under 3 minutes, and the graphics/thumbnail agents were started only after that.
- A sentence-start host shot that the planner snaps onto a nearby jump cut moves, but a HIT anchored at the same raw time does not: the pop-up started 0.5 s inside the previous full-screen card. Anchor hits at the first raw time after the cut (or check lane-3 vs lane-1 overlap from build/timeline.json before export).

## Lessons from Kudrat Care 016 (2026-11-13, Hindi Short, sideways Nikon, review in ~23.5 min)

- A single clean take (102 s, one false start) needs no take triage; the A-roll contact sheet (fps=1, transpose=2, tile) showed she looks at the camera throughout, so no cover for looking away was needed.
- For tabletop b-roll whose file names say what happens but not when, a 5 fps 64x36 frame-difference print per clip (`CLAUDE_VE/scripts/motion.py`) gave every action window (spoon in, pour, stir) in seconds; the first ~2 s of each Nikon clip are a camera bump, not action.
- `windows.py` without `--prompt` leaks its default tech prompt ("आज हम इस product के बारे में बात करेंगे") into short QA windows of the mix; pass a neutral, video-specific prompt, and check English phrases ("By the way") with `--lang en`.
- The hit-vs-card overlap check (lane 3 vs lane 1 and b-roll spine from build/timeline.json) found the same 013 problem again (a hit at a sentence start that the planner moved); run it before every FCP export.
- Two product links can be two brands of the same item; the jar visible in the b-roll settled which one is the hero, both links stay in the description.

## Lessons from Kudrat Care 018 (2026-11-13, Hindi Short, sideways Nikon, sofa set, review in ~23 min)

- Sofa set (018): the creator rejected v1 because pop-ups touched the host's hair. Never estimate the head top from a contact sheet: measure it with a person mask (rembg `u2net_human_seg`) on every 3rd framed frame under each pop-up (018 `scripts/headroom.py`, applies the spine clip's FCP transform), and compare with the pop-up's alpha extent over its slot (shadow included). Hair top was y 288-336 of 1920 (I had guessed 451); `kc_hit` (zone 200-430) overlapped every shot. Fix: `hit_template` "kc_hit_hi" (zone 70-280, made by the 016/017 session for the same set) plus project "hit_pos" (FCP position on all pop-up clips, % of frame height, +y up; [0, 1.667] = 32 px) -> >= 42 px clearance. Do the same check for labels over b-roll with the host in it.
- Pour b-roll (bottle entering from the top, bowl mid-frame) leaves the lower table area empty; step labels belong in y 1150-1480 there, not the usual top band. Look at a conformed mezz frame before writing the label placement into the spec.
- A soft word ending ("sufficient" -> "-ent" at -45..-50 dB) is cut by the -38 dB snap; QA heard "सफी". Windows ending at the snapped point hallucinate; re-transcribe with the out-point 0.3 s later and pin `{"out": "exact"}` where the tail falls below ~-60 dB.
- An "अ" onset before a stop consonant ("अपने": a 0.1 s burst, then the "प" closure) can make the planner start after the burst; pin the in-point in the silence before it.
- Agents report a newer hyperframes "Craft" section (first frame empty, last line < 2 s) that rgfx.py's pinned 0.8.157 does not run; cards under 2 s cannot satisfy the 2 s line rule, so treat it as advisory.

## Lessons from Kudrat Care 017 (2026-11-13, Hindi Short, sideways Nikon, sofa set, review in ~27 min)

- A new set (host on a sofa) puts her head higher (hair top ~0.18 of the frame): the kc_hit zone (y 200-430) sat on her hair and the default 1.18x punch-in pushed the head further up. `CLAUDE_VE_ALL/gfx/templates/kc_hit_hi` (zone y 70-280, 88 px) plus `"tight_anchor": [x, head_top]` keeps pop-ups above the head; check the first `ve.py frames` sheet for pop-ups over hair before exporting.
- Whisper's loops can be the default initial prompt leaking ("आज हम इस product के बारे में बात करेंगे"); short windows looped the same way, so take those words from the full pass and confirm continuity from the 100 ms envelope.
- A 9-frame word piece between two pause cuts is absorbed by the preceding card; a pop-up anchored on it overlaps the card - anchor it after the next cut.
- Both product links can be the same ingredient (two beetroot powder brands); one card with both pouches on the "link दे दिया" line worked.

## Lessons from Kudrat Care 019 (2026-11-13, Hindi Short, sideways Nikon, review in ~25 min)

- `ve.py prep` sets width/height from the raw stream, so a sideways Nikon file (no rotation flag) becomes a 3840x2160 project; set `"width": 2160, "height": 3840` together with `aroll_rotate` right after prep. The mistake showed up only at `ve.py frames` (landscape crop/scale).
- B-roll mezzanines were cached by file name only, so clips conformed before that fix stayed landscape; `broll.render_one` now re-renders a cached mezzanine whose size differs from the project.
- With this host on a sofa, the 1.18x punch-in around `tight_anchor` y 0.38 pushed her hair into the pop-up band; anchor y 0.16 keeps the head at the wide shot's height.
- A single clean take with silent waits needs no windows.py pass: the 100 ms RMS showed -97 dB gaps, and the QA re-transcription still found two clipped word tails (planner out-points ~0.15 s early on slow decays), fixed with `{"out": "exact"}` at the 10 ms envelope.
- Creator's rule (repeated after 016 v1): text over the A-roll must NEVER touch the host's head, hair or body. On the Kudrat sofa set (head top at ~y 345 of 1920 in the wide framing) `kc_hit` (y 200-430) overlapped her hair and the 1.22 punch-ins made it worse. Fix: `kc_hit_hi` (y 70-280) plus `"HW"` (forced wide) on every host VIS anchor that carries a HIT.
  Verify per frame, not per shot: Apple Vision `VNGeneratePersonSegmentationRequest` (accurate, includes hair) on every A-roll frame under a pop-up, AND-ed with the pop-up alpha (`scale,format=rgba,alphaextract`); 532 frames in ~27 s. Script: `016 .../CLAUDE_VE/scratchpad/overlap/` (seg.swift + check.py); copy it to every video before the FCP export.
- Creator's rule, repeated after the 019 review: text over the host must NEVER overlap the head, hair or body. The default `kc_hit` zone (y 200-430) covered the top of her hair on the sofa set; `kc_hit_hi` (y 70-280) clears it by ~170 px. Measure it, don't eyeball it: `019 .../CLAUDE_VE/scripts/overlap.py` compares the alpha box of every pop-up with the top row of dark hair pixels on every 4th frame (a purple ornament behind her head fooled a loose threshold; use lum < 45 and >= 30 px per row).
- Labels over ingredient b-roll: the hand and spoon enter from the top, so labels in the top band sit on them; put them below the bowl (y 1200-1450). Check 3 composited frames per label (start, middle, end), not just the middle.
