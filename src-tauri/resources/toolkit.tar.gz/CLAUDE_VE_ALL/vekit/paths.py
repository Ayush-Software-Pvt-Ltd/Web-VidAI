"""Where things live.  The only module that knows the folder layout.

  <repo>/CLAUDE_VE_ALL/            shared toolkit (this code, venv, design kit, templates, SFX)
  <repo>/<MAIN>/                   one video: A-roll, Details/STYLE.md, info.txt, output/
  <repo>/<MAIN>/CLAUDE_VE/         that video's working files (project.json, timeline.py,
                                   transcripts, graphics, FCP project, builds, previews)

Asset paths stored in timelines are relative to the repo root, so a timeline stays valid
wherever the repo is checked out.
"""
from pathlib import Path

KIT = Path(__file__).resolve().parents[1]          # CLAUDE_VE_ALL
ROOT = KIT.parent                                  # repo root
SHARED = KIT / "gfx" / "_shared"
TEMPLATES = KIT / "gfx" / "templates"
SFX = KIT / "sfx"
DTD = KIT / "vekit" / "FCPXMLv1_14.dtd"


def project_dir(main):
    """Working folder of one video: <repo>/<MAIN>/CLAUDE_VE."""
    return ROOT / main / "CLAUDE_VE"


def rel(path):
    """Repo-relative string for storing in a timeline."""
    return str(Path(path).resolve().relative_to(ROOT))
