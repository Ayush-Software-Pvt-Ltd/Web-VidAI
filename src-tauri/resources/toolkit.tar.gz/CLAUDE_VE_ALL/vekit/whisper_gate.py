"""Machine-wide limit on Whisper processes (creator's rule, 2026-10-23: too many Whisper
processes filled the memory and froze the machine; this must never happen).

Every script that loads a Whisper model calls `acquire()` first.  It takes one of MAX_SLOTS
slot files under CLAUDE_VE_ALL/.whisper/ with an exclusive flock (released by the OS when the
process exits, even on a crash), so no matter how many sessions or scripts start
transcriptions, at most MAX_SLOTS models are loaded at once; the rest wait.  After getting a
slot it also waits until enough memory is available before the model is loaded.
"""
import fcntl
import os
import re
import subprocess
import sys
import time
from pathlib import Path

MAX_SLOTS = 2                 # large-v3 is ~3.6 GB RSS plus GPU buffers per process
MIN_FREE_GB = 12.0            # available memory (free + inactive) needed before loading a model
SLOTS = Path(__file__).resolve().parents[1] / ".whisper"
_held = None                  # the open slot file; kept for the life of the process


def available_gb():
    out = subprocess.run(["vm_stat"], capture_output=True, text=True).stdout
    page = int(re.search(r"page size of (\d+)", out).group(1))
    pages = sum(int(re.search(rf"{k}:\s+(\d+)", out).group(1))
                for k in ("Pages free", "Pages inactive", "Pages speculative"))
    return pages * page / 2 ** 30


def acquire(poll=5.0):
    global _held
    if _held is not None:
        return
    SLOTS.mkdir(exist_ok=True)
    said = False
    while True:
        for n in range(MAX_SLOTS):
            f = open(SLOTS / f"slot{n}.lock", "a+")
            try:
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                f.close()
                continue
            f.seek(0)
            f.truncate()
            f.write(f"pid {os.getpid()} {' '.join(sys.argv)[:300]}\n")
            f.flush()
            _held = f
            break
        if _held is not None:
            break
        if not said:
            print(f"whisper_gate: {MAX_SLOTS} Whisper processes already running, waiting for a slot",
                  file=sys.stderr, flush=True)
            said = True
        time.sleep(poll)
    said = False
    while available_gb() < MIN_FREE_GB:
        if not said:
            print(f"whisper_gate: only {available_gb():.1f} GB available, waiting for {MIN_FREE_GB:.0f} GB",
                  file=sys.stderr, flush=True)
            said = True
        time.sleep(poll)
