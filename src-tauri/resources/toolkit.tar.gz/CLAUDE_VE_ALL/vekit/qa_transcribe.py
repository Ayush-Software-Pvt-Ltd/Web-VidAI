"""Re-transcribe an edited mix to catch clipped words and leftover retake fragments.

Usage: python -m vekit.qa_transcribe <mix.wav> [--window 20] [--out file.txt] [--lang hi|en]
Whisper stops after ~30 s per call and loops on short quiet windows, so the mix is cut
into ~20 s windows on quiet points and each is transcribed alone.  Printed with output
times so suspicious junctions can be found on the timeline.
"""
import argparse
import subprocess

import mlx_whisper
import numpy as np

from .whisper_gate import acquire

SR = 16000


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mix")
    ap.add_argument("--window", type=float, default=20.0)
    ap.add_argument("--out")
    ap.add_argument("--lang", default="hi", help="Whisper language code (hi, en, ...)")
    a = ap.parse_args()
    acquire()                      # at most 2 Whisper processes machine-wide (memory)
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", a.mix, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"],
                         capture_output=True, check=True).stdout
    x = np.frombuffer(raw, dtype=np.float32)
    hop = SR // 100
    n = len(x) // hop
    db = 20 * np.log10(np.sqrt((x[: n * hop].reshape(n, hop) ** 2).mean(axis=1)) + 1e-9)
    lines, t = [], 0.0
    total = len(x) / SR
    while t < total - 0.2:
        end = min(total, t + a.window)
        if end < total:                                  # cut at the quietest 50 ms near the window end
            lo, hi = int((end - 4) * 100), int(end * 100)
            end = (lo + int(np.argmin(np.convolve(db[lo:hi], np.ones(5) / 5, mode="same")))) / 100
        r = mlx_whisper.transcribe(x[int(t * SR):int(end * SR)], path_or_hf_repo="mlx-community/whisper-large-v3-mlx",
                                   language=a.lang, temperature=0.0, condition_on_previous_text=False)
        for s in r["segments"]:
            lines.append(f"{t + s['start']:7.2f}-{t + s['end']:7.2f}  {s['text'].strip()}")
        t = end
    text = "\n".join(lines)
    print(text)
    if a.out:
        open(a.out, "w").write(text + "\n")


if __name__ == "__main__":
    main()
