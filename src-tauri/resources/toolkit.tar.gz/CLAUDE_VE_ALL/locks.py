"""Machine-wide CPU / GPU locks for parallel video-editing sessions.

Whisper, HyperFrames renders and ffmpeg encodes can saturate the machine.  Before a heavy
step, take the matching lock in the REPOSITORY root (never in the video folder).

Preferred form - the lock lives exactly as long as the command:

  python locks.py run cpu --wait 600 --note "whisper large-v3 on 3 parts" -- \
      python transcribe.py ...

Manual form - a lease of 15 minutes, refreshed while you work:

  python locks.py status
  python locks.py acquire cpu --wait 600 --note "2160p graphics render" [--lease 1800]
  python locks.py refresh cpu
  python locks.py release cpu

The lock is `<repo>/cpu.lock` or `<repo>/gpu.lock`, holding the owner pid, a note and a lease.
It is held while the pid is alive OR the lease has not run out; a lock older than 6 h, or with
both a dead pid and an expired lease, is stale and is taken over automatically.  `acquire`
from a short-lived CLI process is therefore still useful (the lease outlives it), but prefer
`run`, which cannot forget to release.
"""
import argparse
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

STALE_S = 6 * 3600
LEASE_S = 900


def repo_root(start=None):
    p = Path(start or os.getcwd()).resolve()
    for d in [p, *p.parents]:
        if (d / "CLAUDE_VE_ALL").exists() or (d / ".git").exists():
            return d
    return p


def read(path):
    try:
        d = json.loads(path.read_text())
    except Exception:
        return None
    return d


def alive(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ValueError):
        return False


def holder(path):
    d = read(path)
    if not d:
        return None
    expired = time.time() - d.get("started", 0) > STALE_S
    if expired:
        return None
    leased = d.get("lease_until", 0) > time.time()
    if not alive(d.get("pid", -1)) and not leased:
        return None
    return d


def describe(path):
    d = holder(path)
    if d:
        age = int(time.time() - d.get("started", 0))
        left = int(max(0, d.get("lease_until", 0) - time.time()))
        live = "alive" if alive(d.get("pid", -1)) else f"lease {left // 60}m{left % 60:02d}s left"
        return (f"HELD by pid {d['pid']} on {d.get('host', '?')} for {age // 60}m ({live})"
                + (f" - {d['note']}" if d.get("note") else ""))
    return "free" + (" (stale lock removed)" if path.exists() else "")


def acquire(path, note, wait, lease=LEASE_S):
    t0 = time.time()
    said = False
    while True:
        d = holder(path)
        if d is None:
            try:
                path.unlink()
            except FileNotFoundError:
                pass
            payload = {"pid": os.getpid(), "host": socket.gethostname(), "started": time.time(),
                       "lease_until": time.time() + lease, "note": note}
            try:
                fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
            except FileExistsError:
                continue
            with os.fdopen(fd, "w") as f:
                json.dump(payload, f)
            print(f"{path.name}: acquired by pid {os.getpid()} for {int(lease)}s"
                  + (f" - {note}" if note else ""))
            return 0
        if wait <= 0 or time.time() - t0 >= wait:
            print(f"{path.name}: {describe(path)}; giving up", file=sys.stderr)
            return 1
        if not said:
            print(f"{path.name}: {describe(path)}; waiting up to {wait}s", file=sys.stderr)
            said = True
        time.sleep(5)


def refresh(path, lease=LEASE_S):
    d = read(path)
    if not d:
        print(f"{path.name}: not held", file=sys.stderr)
        return 1
    d["lease_until"] = time.time() + lease
    d["pid"] = os.getpid()
    path.write_text(json.dumps(d))
    print(f"{path.name}: lease extended to {int(lease)}s")
    return 0


def release(path, force):
    d = read(path)
    if not d:
        print(f"{path.name}: not held")
        return 0
    if not force and d.get("pid") != os.getpid() and alive(d.get("pid", -1)):
        print(f"{path.name}: held by pid {d['pid']}; not ours (use --force)", file=sys.stderr)
        return 1
    path.unlink(missing_ok=True)
    print(f"{path.name}: released")
    return 0


def main():
    argv = sys.argv[1:]
    cmd = []
    if "--" in argv:
        i = argv.index("--")
        argv, cmd = argv[:i], argv[i + 1:]
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["status", "acquire", "release", "refresh", "run"])
    ap.add_argument("lock", nargs="?", choices=["cpu", "gpu"])
    ap.add_argument("--root", help="repository root (default: nearest folder with CLAUDE_VE_ALL)")
    ap.add_argument("--wait", type=float, default=0, help="seconds to wait for a busy lock")
    ap.add_argument("--lease", type=float, default=LEASE_S, help="seconds the lock survives its pid")
    ap.add_argument("--note", default="")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args(argv)
    root = Path(a.root) if a.root else repo_root()
    if a.action == "status":
        for n in ("cpu", "gpu"):
            print(f"{n}.lock: {describe(root / f'{n}.lock')}")
        return 0
    if not a.lock:
        ap.error("acquire/release/refresh/run need cpu or gpu")
    path = root / f"{a.lock}.lock"
    if a.action == "acquire":
        return acquire(path, a.note, a.wait, a.lease)
    if a.action == "refresh":
        return refresh(path, a.lease)
    if a.action == "run":
        if not cmd:
            ap.error("run needs a command after --")
        rc = acquire(path, a.note, a.wait, a.lease)
        if rc:
            return rc
        try:
            return subprocess.call(cmd)
        finally:
            path.unlink(missing_ok=True)
            print(f"{path.name}: released")
    return release(path, a.force)


if __name__ == "__main__":
    sys.exit(main())
