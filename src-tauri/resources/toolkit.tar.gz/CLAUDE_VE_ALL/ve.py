"""Video edit driver.  Run from the repo root with the CLAUDE_VE_ALL venv:

  PY=CLAUDE_VE_ALL/.venv/bin/python
  $PY CLAUDE_VE_ALL/ve.py doctor                    check ffmpeg / VideoToolbox / node / fonts
  $PY CLAUDE_VE_ALL/ve.py prep   <MAIN>             recon the video folder, write project.json, extract audio
  $PY CLAUDE_VE_ALL/ve.py plan   <MAIN>             timeline.py -> build/timeline.json (+ warnings, pacing)
  $PY CLAUDE_VE_ALL/ve.py gfx    <MAIN> [--res 1080 2160]   render the graphics the timeline uses
  $PY CLAUDE_VE_ALL/ve.py broll  <MAIN>             conform the b-roll mezzanines only
  $PY CLAUDE_VE_ALL/ve.py build  <MAIN> --res 720|1080|2160 [--timeline FILE]
                                                    render picture + sound + encode
  $PY CLAUDE_VE_ALL/ve.py fcp    <MAIN>             Final Cut Pro review project (FCPXML 1.14)
  $PY CLAUDE_VE_ALL/ve.py premiere <MAIN>           Premiere Pro review project (FCP7 XML)
  $PY CLAUDE_VE_ALL/ve.py review <MAIN>             fcp on macOS, premiere elsewhere
  $PY CLAUDE_VE_ALL/ve.py import <MAIN> <export.fcpxml|.fcpxmld|.xml>
                                                    read the creator's export -> build/timeline_fcp.json
  $PY CLAUDE_VE_ALL/ve.py frames <MAIN> --res 720    one composited frame per shot + contact sheets
  $PY CLAUDE_VE_ALL/ve.py audio  <MAIN>              render the mix only (loudness check / QA transcription)
  $PY CLAUDE_VE_ALL/ve.py qa     <MAIN> --res 720|2160       contact sheets + pacing + loudness of a render
"""
import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from fractions import Fraction
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from vekit import broll, fcpxml, gfx, premiere, qa, render  # noqa: E402
from vekit.model import Timeline  # noqa: E402
from vekit.paths import DTD, KIT, ROOT, project_dir  # noqa: E402
from vekit.plan import plan  # noqa: E402


def pdir_of(main):
    return project_dir(main)


def pacing(tl):
    """Visible shot lengths (spine framings and lane-1 graphics) for the pacing report."""
    rows = []
    for a, b, base, layers in render.shots_of(tl):
        full = [c for c in layers if c.lane == 1]
        label = full[-1].name if full else ("host x%.2f" % base.scale if base else "black")
        if rows and rows[-1][2] == label and rows[-1][1] == a:
            rows[-1][1] = b
        else:
            rows.append([a, b, label])
    return rows


VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".mts", ".m2ts", ".avi", ".webm"}


def probe_media(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json",
                          str(path)], capture_output=True, text=True, check=True).stdout
    d = json.loads(out)
    v = next((s for s in d["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in d["streams"] if s["codec_type"] == "audio"), None)
    if not v:
        raise RuntimeError(f"no video stream: {path}")
    rot = 0
    for sd in v.get("side_data_list", []):
        if "rotation" in sd:
            rot = int(sd["rotation"])
    rot = int(v.get("tags", {}).get("rotate", rot) or 0)
    w, h = int(v["width"]), int(v["height"])
    if abs(rot) % 180 == 90:
        w, h = h, w
    fps = v.get("r_frame_rate") or "24000/1001"
    dur = float(d["format"].get("duration") or 0)
    n = int(v.get("nb_frames") or 0) or int(round(dur * float(Fraction(fps))))
    return {"file": str(path), "w": w, "h": h, "rot": rot, "fps": fps, "dur": dur, "frames": n,
            "vcodec": v.get("codec_name"), "pix_fmt": v.get("pix_fmt"),
            "audio": bool(a), "achannels": int(a.get("channels", 0)) if a else 0,
            "asr": int(a.get("sample_rate", 0)) if a else 0,
            "timecode": next((s.get("tags", {}).get("timecode") for s in d["streams"]
                              if s.get("codec_tag_string") == "tmcd"), None)}


def cmd_prep(a):
    """Recon the video folder, write project.json, extract the A-roll audio."""
    pdir = pdir_of(a.main)
    vdir = ROOT / a.main
    if not vdir.is_dir():
        raise SystemExit(f"no such video folder: {vdir}")
    for d in ("audio", "gfx_src", "transcripts", "build", "assets", "broll", "thumb_src"):
        (pdir / d).mkdir(parents=True, exist_ok=True)

    # A-roll = Main.* / Main2.* / A-roll* at the top of the video folder; else the largest video
    vids = [p for p in sorted(vdir.iterdir()) if p.is_file() and p.suffix.lower() in VIDEO_EXT]
    named = [p for p in vids if p.stem.lower().startswith(("main", "a-roll", "aroll", "part"))]
    parts = named or sorted(vids, key=lambda p: p.stat().st_size, reverse=True)[:1]
    if not parts:
        raise SystemExit(f"no A-roll video found in {vdir}")
    parts = sorted(parts, key=lambda p: (len(p.stem), p.name))

    pj = pdir / "project.json"
    project = json.loads(pj.read_text()) if pj.exists() else {}
    infos = {f"a{i}": probe_media(p) for i, p in enumerate(parts, 1)}

    first = infos["a1"]
    W, H = (3840, 2160) if first["w"] >= first["h"] else (2160, 3840)
    fps = str(Fraction(first["fps"]))
    project.setdefault("width", W)
    project.setdefault("height", H)
    project["fps"] = fps
    project["aroll"] = {k: Path(v["file"]).name for k, v in infos.items()}
    project["aroll_frames"] = {k: v["frames"] for k, v in infos.items()}
    project.setdefault("final_name", "final_4k.mp4")
    project.setdefault("voice_gain_db", 0.0)
    project.setdefault("tight_scale", 1.18)
    project.setdefault("tight_anchor", [0.5, 0.30])
    project.setdefault("head_top", 0.235)
    project.setdefault("min_framing_frames", 12)
    project.setdefault("energy_threshold_db", -38)
    project.setdefault("hit_template", "hot_hit_16x9" if W > H else "hot_hit")
    project.setdefault("end_template", "end_fade_16x9" if W > H else "end_fade")
    project.setdefault("hit_media_seconds", 6.0)
    project.setdefault("hit_lane", 3)
    project.setdefault("end_lane", 4)
    project.setdefault("sfx_whoosh_db", -12.0)
    project.setdefault("sfx_pop_db", -14.0)
    project.setdefault("whoosh_on", "all")
    pj.write_text(json.dumps(project, indent=1))

    for k, v in infos.items():
        src = Path(v["file"])
        w48 = pdir / "audio" / f"{k}_48k.wav"
        w16 = pdir / "audio" / f"{k}_16k.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(src), "-vn", "-ac", "2", "-ar", "48000",
                        "-c:a", "pcm_s24le", str(w48)], check=True)
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000",
                        "-c:a", "pcm_s16le", str(w16)], check=True)
        v["audio_48k"] = str(w48.relative_to(ROOT))
        v["audio_16k"] = str(w16.relative_to(ROOT))
        print(f"{k}  {src.name}  {v['w']}x{v['h']} (rot {v['rot']})  {v['fps']}  "
              f"{v['dur']:.2f}s  {v['frames']} frames  {v['vcodec']} {v['pix_fmt']}  "
              f"audio {'yes' if v['audio'] else 'NO'}"
              + (f"  tc {v['timecode']}" if v["timecode"] else ""))

    (pdir / "build" / "recon.json").write_text(json.dumps(infos, indent=1))
    print(f"project {project['width']}x{project['height']} @ {fps} -> {pj.relative_to(ROOT)}")

    others = [p for p in sorted(vdir.rglob("*")) if p.is_file() and p.suffix.lower() in VIDEO_EXT
              and p not in parts and "CLAUDE_VE" not in p.parts and "output" not in p.parts]
    if others:
        print(f"{len(others)} other video file(s) to catalogue as b-roll:")
        for p in others:
            print("  ", p.relative_to(vdir))


def cmd_plan(a):
    tl, warns = plan(a.main)
    f2s = tl.f2s
    rows = pacing(tl)
    lens = [f2s(b - s) for s, b, _ in rows]
    nb = sum(1 for c in tl.connected if c.lane == 1 and tl.assets[c.asset]["kind"] == "broll")
    print(f"duration {f2s(tl.duration):.2f}s, {len(tl.spine)} spine clips, "
          f"{sum(1 for c in tl.connected if c.lane == 1) - nb} graphics, {nb} b-roll, "
          f"{sum(1 for c in tl.connected if c.asset.startswith('gfx:hit_'))} hits, "
          f"{sum(1 for c in tl.connected if c.lane == 2 and not c.asset.startswith('gfx:hit_'))} overlays")
    print(f"visible shots {len(rows)}, mean {sum(lens) / len(lens):.2f}s, max {max(lens):.2f}s")
    if a.verbose:
        for s, b, label in rows:
            flag = "  <-- long" if f2s(b - s) > 3.2 and not label.startswith("check") else (
                "  <-- short" if f2s(b - s) < 0.6 else "")
            print(f"  {f2s(s):7.2f} {f2s(b - s):5.2f}s  {label}{flag}")
    for w in warns:
        print("WARN", w)
    # synced b-roll (a second angle such as a screen recording) is different footage every time
    # and a graphic resumed after a cut to the host (in-point > 0) is the same use continuing
    names = [c.name for c in tl.connected if c.lane == 1 and "ranges" not in tl.assets[c.asset]
             and not (tl.assets[c.asset]["kind"] == "gfx" and c.src > 0)]
    for n in sorted(set(names)):
        if names.count(n) > 2:
            print("WARN graphic/b-roll used more than twice:", n)


def load_tl(a):
    p = Path(a.timeline) if getattr(a, "timeline", None) else pdir_of(a.main) / "build" / "timeline.json"
    return Timeline.load(p)


def cmd_gfx(a):
    tl = load_tl(a)
    gfx.render_all(tl, pdir_of(a.main), [int(r) for r in a.res], force=a.force)


def cmd_broll(a):
    tl = load_tl(a)
    broll.render_all(tl)


def cmd_build(a):
    main, res = a.main, int(a.res)
    pdir = pdir_of(main)
    tl = load_tl(a)
    project = json.loads((pdir / "project.json").read_text())
    gfx.render_all(tl, pdir, [2160 if res == 2160 else 1080])
    broll.render_all(tl)
    concat = render.render_video(tl, pdir, res)
    audio, loud = render.render_audio(tl, pdir, res)
    if res == 2160:
        out = ROOT / main / "output" / project["final_name"]
    else:
        out = pdir / "renders" / f"preview_{res}.mp4"
    render.mux(concat, audio, out, res, tl.rate.ff)
    info = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                           "stream=codec_name,width,height,r_frame_rate,bit_rate:format=duration,bit_rate",
                           "-of", "compact", str(out)], capture_output=True, text=True).stdout
    print(info.strip())
    (pdir / "build" / str(res) / "render_info.json").write_text(json.dumps({"out": str(out), **loud}, indent=1))


def _validate_fcp(out):
    if DTD.exists():
        r = subprocess.run(["xmllint", "--noout", "--dtdvalid", str(DTD), str(out)], capture_output=True, text=True)
        print("DTD validation:", "OK" if r.returncode == 0 else r.stderr[-2000:])


def cmd_fcp(a):
    pdir = pdir_of(a.main)
    tl = load_tl(a)
    gfx.render_all(tl, pdir, [1080])
    broll.render_all(tl)
    name = Path(a.main).name                 # MAIN may be "<CHANNEL>/<VIDEO>"
    # the review project is a deliverable: it goes to <MAIN>/output/ (creator's rule, 2026-10-16);
    # its media stay in CLAUDE_VE
    out = ROOT / a.main / "output" / f"{name}_review_{a.version}.fcpxml"
    out.parent.mkdir(parents=True, exist_ok=True)
    fcpxml.write(tl, out, f"{name} review {a.version}", pdir / "gfx" / "1080")
    _validate_fcp(out)
    # round-trip self check: reading our own file must give back the same timeline
    warns = []
    back = fcpxml.read(out, tl.assets, warns, tl.fps)
    same = diff(tl, back)
    print("round trip:", "identical" if not same else "\n  ".join(["DIFFERS"] + same))
    for w in warns:
        print("WARN", w)
    print(out)


def cmd_premiere(a):
    pdir = pdir_of(a.main)
    tl = load_tl(a)
    gfx.render_all(tl, pdir, [1080])
    broll.render_all(tl)
    name = Path(a.main).name
    out = ROOT / a.main / "output" / f"{name}_review_{a.version}.xml"
    out.parent.mkdir(parents=True, exist_ok=True)
    premiere.write(tl, out, f"{name} review {a.version}", pdir / "gfx" / "1080")
    problems = premiere.check(out)
    print("media check:", "OK" if not problems else "\n  ".join(["PROBLEMS"] + problems[:20]))
    n = len(list(ET.parse(out).getroot().iter("clipitem")))
    print(f"{n} clipitems, sequence {tl.f2s(tl.duration):.2f}s")
    print(out)


def cmd_review(a):
    if a.software == "fcp" or (a.software == "auto" and platform.system() == "Darwin"):
        cmd_fcp(a)
    else:
        cmd_premiere(a)


def diff(t1, t2):
    out = []
    key = lambda c: (c.rec, c.lane, c.asset, c.src, c.dur, round(c.scale, 4), tuple(round(v, 3) for v in c.pos),
                     round(c.volume_db, 2), c.fade_in, c.fade_out, c.video, c.audio)
    a = sorted(key(c) for c in t1.spine + t1.connected)
    b = sorted(key(c) for c in t2.spine + t2.connected)
    for x in a:
        if x not in b:
            out.append(f"only in ours: {x}")
    for x in b:
        if x not in a:
            out.append(f"only in FCP:  {x}")
    if t1.duration != t2.duration:
        out.append(f"duration {t1.duration} vs {t2.duration} frames")
    return out


def cmd_import(a):
    pdir = pdir_of(a.main)
    ours = Timeline.load(pdir / "build" / "timeline.json")
    warns = []
    if str(a.export).lower().endswith(".xml"):
        tl = premiere.read(a.export, ours.assets, warns, ours.fps)
    else:
        tl = fcpxml.read(a.export, ours.assets, warns, ours.fps)
    tl.meta = {"main": a.main, "source": str(a.export)}
    out = pdir / "build" / "timeline_fcp.json"
    tl.save(out)
    d = diff(ours, tl)
    print(f"review timeline: {tl.f2s(tl.duration):.2f}s ({tl.duration} frames), {len(tl.spine)} spine items, "
          f"{len(tl.connected)} connected")
    print(f"{len(d)} differences from the exported review timeline")
    for x in d[:200]:
        print("  ", x)
    for w in warns:
        print("WARN", w)
    print(out)


def shot_label(tl, base, layers):
    full = [c for c in layers if c.lane == 1]
    if full:
        return full[-1].name
    if base is None:
        return "black"
    return "host x%.2f" % base.scale


def cmd_frames(a):
    tl = load_tl(a)
    pdir = pdir_of(a.main)
    res = int(a.res)
    outdir = pdir / "build" / str(res) / "qa_frames"
    outdir.mkdir(parents=True, exist_ok=True)
    shots = render.shots_of(tl)
    items, sheet_no = [], 1
    for i, (s, b, base, layers) in enumerate(shots):
        mid = s + max(0, (b - s) // 2)
        out = outdir / f"shot_{i:03d}.jpg"
        cmd = render.frame_cmd(tl, pdir, res, mid, base, layers, out)
        r = subprocess.run(cmd, capture_output=True, text=True, stdin=subprocess.DEVNULL)
        if r.returncode != 0:
            raise RuntimeError(f"frame {i} failed:\n{' '.join(cmd)}\n{r.stderr[-1500:]}")
        items.append((out, f"{tl.f2s(s):.1f}s {shot_label(tl, base, layers)}"))
    sheets = []
    for k in range(0, len(items), 36):
        sheet = pdir / "build" / str(res) / f"qa_sheet_{sheet_no}.jpg"
        qa.tile(items[k:k + 36], sheet, cols=6, width=300)
        sheets.append(sheet)
        sheet_no += 1
    for s in sheets:
        print(s)
    print(f"{len(items)} shots, {len(sheets)} sheets")


def cmd_audio(a):
    tl = load_tl(a)
    pdir = pdir_of(a.main)
    mix, loud = render.render_audio(tl, pdir, 720)
    print(mix)
    print(f"loudness {loud['lufs']:.1f} LUFS, true peak {loud['true_peak']:.1f} dBTP")


def cmd_qa(a):
    pdir = pdir_of(a.main)
    project = json.loads((pdir / "project.json").read_text())
    res = int(a.res)
    out = ROOT / a.main / "output" / project["final_name"] if res == 2160 else pdir / "renders" / f"preview_{res}.mp4"
    tl = load_tl(a)
    rows = pacing(tl)
    mids = [round(tl.f2s((s + b) // 2), 3) for s, b, _ in rows]
    qdir = pdir / "build" / str(res) / "qa"
    qdir.mkdir(parents=True, exist_ok=True)
    for i in range(0, len(mids), 40):
        subprocess.run([sys.executable, str(KIT / "sheet.py"), str(out),
                        str(qdir / f"shots_{i // 40 + 1}.jpg"), "--times", ",".join(map(str, mids[i:i + 40])),
                        "--cols", "10", "--width", "200"], check=True)
    i, tp = render.loudness(out)
    print(f"loudness {i:.1f} LUFS, true peak {tp:.1f} dBTP")


def cmd_doctor(a):
    ok = True
    for exe in ("ffmpeg", "ffprobe", "xmllint", "node", "npx"):
        p = shutil.which(exe)
        print(f"{exe:8s} {'OK  ' + p if p else 'MISSING'}")
        ok &= bool(p)
    enc = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True).stdout
    for e in ("prores_videotoolbox", "h264_videotoolbox", "hevc_videotoolbox"):
        print(f"encoder {e:22s} {'OK' if e in enc else 'MISSING'}")
        ok &= e in enc
    try:
        import mlx_whisper  # noqa: F401
        print("mlx-whisper OK")
    except Exception as e:
        print("mlx-whisper MISSING:", e)
        ok = False
    print("platform", platform.system(), platform.machine(), "python", platform.python_version())
    print("repo", ROOT, "kit", KIT)
    print("Final Cut Pro app:", "present" if Path("/Applications/Final Cut Pro.app").exists() else "not found")
    print("result:", "READY" if ok else "INCOMPLETE")
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("plan"); p.add_argument("main"); p.add_argument("-v", "--verbose", action="store_true")
    p = sub.add_parser("gfx"); p.add_argument("main"); p.add_argument("--res", nargs="+", default=["1080"])
    p.add_argument("--force", action="store_true"); p.add_argument("--timeline")
    p = sub.add_parser("broll"); p.add_argument("main"); p.add_argument("--timeline")
    p = sub.add_parser("build"); p.add_argument("main"); p.add_argument("--res", required=True); p.add_argument("--timeline")
    p = sub.add_parser("fcp"); p.add_argument("main"); p.add_argument("--version", default="v1"); p.add_argument("--timeline")
    p = sub.add_parser("premiere"); p.add_argument("main"); p.add_argument("--version", default="v1"); p.add_argument("--timeline")
    p = sub.add_parser("review"); p.add_argument("main"); p.add_argument("--version", default="v1")
    p.add_argument("--software", default="auto", choices=["auto", "fcp", "premiere"]); p.add_argument("--timeline")
    p = sub.add_parser("import"); p.add_argument("main"); p.add_argument("export")
    p = sub.add_parser("frames"); p.add_argument("main"); p.add_argument("--res", default="720"); p.add_argument("--timeline")
    p = sub.add_parser("audio"); p.add_argument("main"); p.add_argument("--timeline")
    p = sub.add_parser("qa"); p.add_argument("main"); p.add_argument("--res", required=True); p.add_argument("--timeline")
    p = sub.add_parser("prep"); p.add_argument("main")
    sub.add_parser("doctor")
    a = ap.parse_args()
    {"prep": cmd_prep, "plan": cmd_plan, "gfx": cmd_gfx, "broll": cmd_broll, "build": cmd_build,
     "fcp": cmd_fcp, "premiere": cmd_premiere,
     "review": cmd_review, "import": cmd_import, "frames": cmd_frames, "audio": cmd_audio,
     "qa": cmd_qa, "doctor": cmd_doctor}[a.cmd](a)


if __name__ == "__main__":
    main()
